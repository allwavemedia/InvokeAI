"""
Initialization file for invokeai.frontend.web
"""
