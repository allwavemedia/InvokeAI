"""
Initialization file for invokeai.frontend.config
"""
