"""
Initialization file for invokeai.frontend.CLI
"""
from .CLI import main as invokeai_command_line_interface  # noqa: F401
