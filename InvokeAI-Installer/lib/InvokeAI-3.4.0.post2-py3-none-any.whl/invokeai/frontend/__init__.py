"""
Initialization file for invokeai.frontend
"""
