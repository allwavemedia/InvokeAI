class WorkflowNotFoundError(Exception):
    """Raised when a workflow is not found"""
