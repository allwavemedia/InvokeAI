from abc import ABC


class InvocationProcessorABC(ABC):  # noqa: B024
    pass
